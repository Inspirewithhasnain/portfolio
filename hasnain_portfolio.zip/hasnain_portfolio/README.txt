HASNAIN HANIF - PREMIUM PORTFOLIO
=================================

FILES
- index.html : page structure
- style.css  : design and responsive styling
- script.js  : signup, login, LocalStorage and interactions

HOW TO RUN
1. Extract the ZIP.
2. Open the folder.
3. Double-click index.html, or open it with VS Code Live Server.

FLOW
Loading -> Signup (first visit) -> Login -> Portfolio
After registration, the account is saved in this browser's LocalStorage.
After login, the session is remembered until Log out is clicked.

IMPORTANT SECURITY NOTE
This is a front-end learning/demo authentication system. The password is stored in
browser LocalStorage and can be viewed by someone with access to browser storage.
Do not use a real or reused password. A public production website needs secure
server-side authentication (for example, Supabase Auth or another backend).

CUSTOMIZE
- Change the contact email in index.html (search for hello@example.com).
- Edit your intro, skills and project descriptions in index.html.
- Account data keys: hh_portfolio_account and hh_portfolio_session.
