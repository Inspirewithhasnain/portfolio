const $ = (id) => document.getElementById(id);
const ACCOUNT_KEY = "hh_portfolio_account";
const SESSION_KEY = "hh_portfolio_session";

const loader = $("loader");
const signupScreen = $("signupScreen");
const loginScreen = $("loginScreen");
const site = $("site");

function showOnly(screen) {
  [signupScreen, loginScreen, site].forEach(item => item.classList.add("hidden"));
  screen.classList.remove("hidden");
}
function runLoader(nextAction) {
  loader.classList.remove("hidden");
  const bar = $("progressBar");
  const label = $("loadingText");
  let progress = 0;
  bar.style.width = "0%";
  label.textContent = "Preparing your experience · 0%";
  const timer = setInterval(() => {
    progress += Math.floor(Math.random() * 13) + 7;
    if (progress > 100) progress = 100;
    bar.style.width = progress + "%";
    label.textContent = "Preparing your experience · " + progress + "%";
    if (progress >= 100) {
      clearInterval(timer);
      setTimeout(() => {
        loader.classList.add("hidden");
        nextAction();
      }, 250);
    }
  }, 100);
}
function getAccount() {
  const raw = localStorage.getItem(ACCOUNT_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch (error) {
    localStorage.removeItem(ACCOUNT_KEY);
    return null;
  }
}
function showSignup() {
  $("signupMessage").textContent = "";
  showOnly(signupScreen);
}
function showLogin() {
  $("loginMessage").textContent = "";
  showOnly(loginScreen);
}
function showPortfolio() {
  const account = getAccount();
  const session = localStorage.getItem(SESSION_KEY);
  if (!account || !session || session !== account.email) {
    localStorage.removeItem(SESSION_KEY);
    showLogin();
    return;
  }
  $("welcomeUser").textContent = account.name;
  $("year").textContent = new Date().getFullYear();
  showOnly(site);
  window.scrollTo(0, 0);
}

$("signupForm").addEventListener("submit", function(event) {
  event.preventDefault();
  const name = $("signupName").value.trim();
  const email = $("signupEmail").value.trim().toLowerCase();
  const password = $("signupPassword").value;
  const confirm = $("confirmPassword").value;
  const message = $("signupMessage");
  message.classList.remove("success");
  if (name.length < 2) { message.textContent = "Please enter your full name."; return; }
  if (password.length < 6) { message.textContent = "Password must be at least 6 characters."; return; }
  if (password !== confirm) { message.textContent = "Passwords do not match."; return; }
  const existing = getAccount();
  if (existing && existing.email === email) {
    message.textContent = "This email is already registered. Please log in.";
    return;
  }
  const account = { name, email, password };
  localStorage.setItem(ACCOUNT_KEY, JSON.stringify(account));
  message.textContent = "Account created! Taking you to login...";
  message.classList.add("success");
  this.reset();
  setTimeout(() => runLoader(showLogin), 650);
});

$("loginForm").addEventListener("submit", function(event) {
  event.preventDefault();
  const email = $("loginEmail").value.trim().toLowerCase();
  const password = $("loginPassword").value;
  const message = $("loginMessage");
  const account = getAccount();
  message.classList.remove("success");
  if (!account) {
    message.textContent = "No account found. Please create an account first.";
    return;
  }
  if (email !== account.email || password !== account.password) {
    message.textContent = "Email or password is incorrect.";
    return;
  }
  localStorage.setItem(SESSION_KEY, account.email);
  message.textContent = "Login successful!";
  message.classList.add("success");
  this.reset();
  setTimeout(() => runLoader(showPortfolio), 350);
});

$("showLogin").addEventListener("click", () => runLoader(showLogin));
$("showSignup").addEventListener("click", () => runLoader(showSignup));
$("logoutBtn").addEventListener("click", () => {
  localStorage.removeItem(SESSION_KEY);
  runLoader(showLogin);
  toast("You have been logged out.");
});

const projectData = {
  courses: {
    title: "MHH Courses",
    description: "A personal education website concept designed to present web development courses and demonstrate a simple shopping and registration experience.",
    features: ["Course cards and product details", "Cart and checkout interface concept", "Student registration flow"]
  },
  eatens: {
    title: "Eatens POS",
    description: "A restaurant point-of-sale interface concept focused on making menu selection and bill preparation straightforward.",
    features: ["Food menu and category layout", "Cart with quantity controls", "Printable bill interface concept"]
  },
  perfume: {
    title: "MHH Perfume",
    description: "A premium storefront concept for a perfume brand, with an emphasis on product visuals and a refined dark presentation.",
    features: ["Premium product presentation", "Perfume category sections", "Responsive storefront layout"]
  }
};
function openProject(key) {
  const project = projectData[key];
  if (!project) return;
  $("modalTitle").textContent = project.title;
  $("modalDescription").textContent = project.description;
  $("modalFeatures").innerHTML = "";
  project.features.forEach(feature => {
    const item = document.createElement("div");
    item.textContent = feature;
    $("modalFeatures").appendChild(item);
  });
  $("projectModal").classList.remove("hidden");
}
function closeProject() { $("projectModal").classList.add("hidden"); }
document.querySelectorAll("[data-open]").forEach(button => {
  button.addEventListener("click", () => openProject(button.dataset.open));
});
$("closeModal").addEventListener("click", closeProject);
$("modalDone").addEventListener("click", closeProject);
$("projectModal").addEventListener("click", event => {
  if (event.target.dataset.close) closeProject();
});
document.addEventListener("keydown", event => {
  if (event.key === "Escape") closeProject();
});

$("menuToggle").addEventListener("click", () => $("navLinks").classList.toggle("open"));
document.querySelectorAll("#navLinks a").forEach(link => {
  link.addEventListener("click", () => {
    $("navLinks").classList.remove("open");
    document.querySelectorAll("#navLinks a").forEach(item => item.classList.remove("active"));
    link.classList.add("active");
  });
});

let toastTimer;
function toast(message) {
  const box = $("toast");
  box.textContent = message;
  box.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => box.classList.remove("show"), 2300);
}

// Initial route: loader first, then a saved session, login, or signup.
runLoader(() => {
  const account = getAccount();
  const session = localStorage.getItem(SESSION_KEY);
  if (account && session === account.email) showPortfolio();
  else if (account) showLogin();
  else showSignup();
});
